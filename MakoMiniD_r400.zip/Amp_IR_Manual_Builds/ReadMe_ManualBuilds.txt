MANUALLY BUILDING AMPLIFIERS
Mako Distortion 2 uses Impulse Responses to model amplifier input EQs. These IRs are usually made from
frequency sweeps of amplifiers. But that is not completely necessary. You can build your own amps.

Our program of choice for WAVE file editing is Goldwave, but you can use any good audio editor. 

To begin, you need to create a full response IR. This is an IR that has a single sample at full volume.
The sample should be the first sample in the wave file. 

The file 1_base_IR is already built for you and included in the ZIP file.

STEPS:
1) Create the full response IR (1_base_IR.wav).
2) Apply EQs to the IR. Pay attention to EQs that destroy the phase relationship.
3) Normalize the IR volume (Peak). ie Make the loudest sample full volume. 
4) Save as WAVE file. 

SAMPLE RATE
Mako Distortion is designed to run at a sample rate of 48 kHz. It can be run at different rates, but
it does not try to resample IRs for differing rates. Your results may vary.

BASIC AMP DESIGN
1) Amps usually employ some form of high pass filter between 50-200 Hz.
2) The higher the gain used, the less bass you want in the amp front end.
3) Clean amps have a gradual high freq boost above 1 kHz.
4) Most guitars do not create sounds above 5 kHz. You may get good results cutting freqs above 5K.
5) High gain amps have mid boosts between 700-1500 Hz.

GOLDWAVE FILTERS TO USE THAT KEEP PHASE
- Low/Pass filter
- Parametric EQ
- Spectrum Filter

GOLDWAVE FILTERS TO USE THAT DO NOT KEEP PHASE
- Equalizer